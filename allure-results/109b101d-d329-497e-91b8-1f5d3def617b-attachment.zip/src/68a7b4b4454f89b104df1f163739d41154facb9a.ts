
import {test} from '../fixtures/BaseTest';

test('checkout process', async({page,
     homepage,
     electronics,
     cameraPhoto,
     loginPage,

    })=>{

        await homepage.clickLogin();
        await loginPage.Loginuser('haplap@gmail.com','hp@123');
        await loginPage.clickLogIn();
        await electronics.clickCameraPhoto();
        
        
});
import { Page,Locator } from '@playwright/test';

export class BillingAddress{
    readonly page:Page;
    readonly Firstname:Locator;
    constructor(page:Page){
        this.page = page;
        this.Firstname = page.getByLabel('First name:'); 
    }

    async enterFirstName(name:string){
        await this.Firstname.fill(name);
    }
}
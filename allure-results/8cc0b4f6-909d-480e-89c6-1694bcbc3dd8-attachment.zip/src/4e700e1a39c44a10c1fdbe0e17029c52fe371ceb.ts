import {Page,Locator} from '@playwright/test';

export class ShoppingCart{

    readonly page:Page;
    readonly checkbox:Locator;
    readonly termsOfService;

    constructor(page:Page){
        this.page = page;
        this.checkbox = page.locator("//input[@name='removefromcart']");
        this.termsOfService = page.locator('input#termsofservice');
    }

    async clickCheckbox(){
        await this.checkbox.check();
    }

    async clickTermsOfService(){
        await this.termsOfService.check();
    }
}
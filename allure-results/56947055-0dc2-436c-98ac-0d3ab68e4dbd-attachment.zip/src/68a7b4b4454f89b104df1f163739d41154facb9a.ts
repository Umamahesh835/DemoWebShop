
import { expect } from 'playwright/test';
import {test} from '../fixtures/BaseTest';

test('checkout process', async({page,
     homepage,
     electronics,
     cameraPhoto,
     contextMenu,
     loginPage,
     cellPhones,
     shoppingcart,
     billingAddress,


    })=>{

        await page.goto('https://demowebshop.tricentis.com/');
        await homepage.clickLogin();
        await loginPage.Loginuser('haplap@gmail.com','hp@123');
        await loginPage.clickLogIn();
        await contextMenu.clickElectronics();
        await electronics.clickCellPhones();
        await cellPhones.clickProductNames('Smartphone');
        await page.waitForURL('https://demowebshop.tricentis.com/smartphone');
        await cellPhones.clickAddToCart();
        await cellPhones.getCarttext();
        await cellPhones.clickShoppingcart();
        await page.waitForURL('https://demowebshop.tricentis.com/cart');
        await shoppingcart.clickTermsOfService();
        await expect(shoppingcart.termsOfService).toBeChecked();
        await shoppingcart.clickCheckOut();
        await page.waitForURL('https://demowebshop.tricentis.com/onepagecheckout');
        await billingAddress.enterFirstName('Mahesh');
        await page.waitForLoadState('networkidle');
        await billingAddress.selectCountry('India');
        

        

});
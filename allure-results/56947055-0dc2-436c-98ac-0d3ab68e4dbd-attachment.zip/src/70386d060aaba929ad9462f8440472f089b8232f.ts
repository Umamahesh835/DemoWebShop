import { Page,Locator } from '@playwright/test';

export class BillingAddress{
    readonly page:Page;
    readonly Firstname:Locator;
    readonly Lastname:Locator;
    readonly Email:Locator;
    readonly Country:Locator;


    constructor(page:Page){

        this.page = page;
        this.Firstname = page.getByLabel('First name:'); 
        this.Lastname = page.getByLabel('Last name:');
        this.Email = page.getByLabel('Email:');
        this.Country = page.locator('#BillingNewAddress_CountryId');

    }

    async enterFirstName(name:string){
        await this.Firstname.fill(name);
    }
    async enterLastName(name:string){
        await this.Lastname.fill(name);
    }
    async enterEmail(email:string){
        await this.Email.fill(email);
    }

    async selectCountry(country: string) {

    const options = await this.Country.locator('option').allTextContents();

    for (let i = 0; i < options.length; i++) {

        if (options[i].trim() === country) {

            await this.Country.selectOption({ label: country });
            break;
        }
    }
}
}
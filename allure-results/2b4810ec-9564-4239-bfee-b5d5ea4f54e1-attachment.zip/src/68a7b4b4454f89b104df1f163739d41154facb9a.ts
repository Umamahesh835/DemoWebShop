
import {test} from '../fixtures/BaseTest';

test('checkout process', async({page,
     homepage,
     electronics,
     cameraPhoto,
     contextMenu,
     loginPage,
     cellPhones,


    })=>{

        await page.goto('https://demowebshop.tricentis.com/');
        await homepage.clickLogin();
        await loginPage.Loginuser('haplap@gmail.com','hp@123');
        await loginPage.clickLogIn();
        await contextMenu.clickElectronics();
        await electronics.clickCellPhones();
        await cellPhones.clickProductNames('Used phone');
        

        
});
import {Page, Locator} from '@playwright/test';

export class CellPhones{

    readonly page:Page;
    readonly ProductNames:Locator;

    constructor(page:Page){
        this.page = page;
        this.ProductNames = page.locator('.details h2');
    }

    async clickProductNames(name:string){
        const productName = await this.ProductNames.innerText();
        console.log(productName);

        const count = await this.ProductNames.count();

        for(let i=0;i<count;i++){
            const pNames  = await this.ProductNames.nth(i).innerText();
            
            if(pNames.trim()=== name){
                await this.ProductNames.nth(i).click();
                break;
            }
        }
    }
}
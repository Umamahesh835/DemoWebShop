import {Page,Locator} from '@playwright/test';

export class ShoppingCart{

    readonly page:Page;
    readonly checkbox:Locator;

    constructor(page:Page){
        this.page = page;
        this.checkbox = page.getByRole('checkbox', {name: 'checkbox'});

    }

    async clickCheckbox(){
        await this.checkbox.first().click();
    }
}
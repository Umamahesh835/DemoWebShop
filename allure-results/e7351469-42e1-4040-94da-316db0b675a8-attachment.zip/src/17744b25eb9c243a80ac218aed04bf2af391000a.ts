import {Page, Locator} from '@playwright/test';

export class CellPhones{

    readonly page:Page;
    readonly ProductNames:Locator;
    readonly AddToCart:Locator;

    constructor(page:Page){
        this.page = page;
        this.ProductNames = page.locator('.details h2');
        this.AddToCart = page.getByRole('button', { name: 'Add to cart'});
    }

    async clickProductNames(name: string) {
    const count = await this.ProductNames.count();
    for (let i = 0; i < count; i++) {

        const productName = await this.ProductNames.nth(i).innerText();

        if (productName.trim() === name) {
            console.log("the product name is :",productName);
            await this.ProductNames.nth(i).click();
            break;
        }
    }
}

    async clickAddToCart(){
        await this.AddToCart.first().click();
    }
}

